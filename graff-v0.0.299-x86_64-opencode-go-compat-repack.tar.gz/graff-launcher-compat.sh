#!/bin/sh
set -eu
mkdir -p .graff
cat > .graff/.config.router << 'ROUTER'
{
  "id": "opencode-go-compat",
  "name": "OpenCode Go Compat (via gateway)",
  "base_url": "http://172.17.0.1:18924/v1",
  "env_key": "OPENCODE_GO_API_KEY",
  "default_model": "muse-spark-1.2-contributor",
  "takes_effort": true
}
ROUTER
echo "[graff-launcher-compat] CWD=$(pwd) router=$(cat .graff/.config.router | tr -d '\n')" >&2
echo "[graff-launcher-compat] KEY_SET=$([ -n "$OPENCODE_GO_API_KEY" ] && echo YES || echo NO)" >&2
# Gateway is on host at 172.17.0.1:18924, already running, no need to start inside container
exec "$(dirname "$0")/graff" "$@"
