#!/usr/bin/env python3
"""Symmetric compatibility gateway: Chat Completions <-> Responses for OpenCode Go.

Accepts POST /v1/chat/completions (chat) and converts deterministically to POST /v1/responses (responses)
for muse-spark-1.2-contributor, preserving model, reasoning effort low, tools, and session isolation.
Same implementation/version used by both JCode and Graff (opencode-go-compat).
"""
import http.server
import os
import sys
import json
import uuid
import urllib.request
import urllib.error
import time

UPSTREAM = "https://opencode.ai/zen/go"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else int(os.environ.get("COMPAT_PORT", "18924"))
SESSION_ENV = "OPENCODE_GO_API_KEY"
_USER_AGENT = "python-http-client/1.0"

# For logging redacted requests
LOG_DIR = os.environ.get("COMPAT_LOG_DIR", "/tmp/compat-gateway-logs")
os.makedirs(LOG_DIR, exist_ok=True)

def redacted_log(name, data):
    try:
        path = os.path.join(LOG_DIR, f"{name}.jsonl")
        with open(path, "a") as f:
            f.write(json.dumps(data) + "\n")
    except:
        pass

def get_auth_header(headers):
    auth = headers.get("Authorization")
    if auth:
        return auth
    api_key = os.environ.get(SESSION_ENV, "")
    if api_key:
        return f"Bearer {api_key}"
    return None

def chat_to_responses(chat_body):
    model = chat_body.get("model")
    messages = chat_body.get("messages", [])
    tools = chat_body.get("tools", [])
    tool_choice = chat_body.get("tool_choice")
    temperature = chat_body.get("temperature")
    max_tokens = chat_body.get("max_tokens") or chat_body.get("max_completion_tokens") or chat_body.get("max_output_tokens")
    # effort detection
    effort = "low"
    if "reasoning_effort" in chat_body:
        effort = chat_body["reasoning_effort"]
    elif "reasoning" in chat_body and isinstance(chat_body["reasoning"], dict):
        effort = chat_body["reasoning"].get("effort", "low")
    elif "effort" in chat_body:
        effort = chat_body["effort"]
    # JCode may send JCODE_OPENAI_REASONING_EFFORT via env not body, but we default low for campaign
    if effort not in ["low","medium","high","xhigh","max"]:
        effort = "low"

    instructions = None
    input_items = []
    for msg in messages:
        role = msg.get("role")
        content = msg.get("content")
        if isinstance(content, list):
            # multimodal: concat text parts
            text = " ".join([p.get("text","") for p in content if isinstance(p,dict) and p.get("type")=="text"])
        else:
            text = content or ""
        if role == "system":
            if instructions is None:
                instructions = text
            else:
                instructions += "\n" + text
        elif role == "user":
            input_items.append({"role":"user","content": text})
        elif role == "assistant":
            tool_calls = msg.get("tool_calls")
            if tool_calls:
                for tc in tool_calls:
                    func = tc.get("function", {})
                    name = func.get("name")
                    arguments = func.get("arguments", "{}")
                    call_id = tc.get("id", f"call_{uuid.uuid4().hex[:8]}")
                    input_items.append({"type":"function_call","call_id": call_id, "name": name, "arguments": arguments})
                if text:
                    input_items.append({"role":"assistant","content": text})
            else:
                input_items.append({"role":"assistant","content": text})
        elif role == "tool":
            tool_call_id = msg.get("tool_call_id") or msg.get("tool_call_id")
            input_items.append({"type":"function_call_output","call_id": tool_call_id, "output": text})
        else:
            input_items.append({"role": role, "content": text})

    payload = {
        "model": model,
        "input": input_items if input_items else "Hello",
        "reasoning": {"effort": effort}
    }
    if instructions:
        payload["instructions"] = instructions
    if tools:
        resp_tools = []
        for t in tools:
            if t.get("type") == "function":
                func = t.get("function", {})
                resp_tools.append({
                    "type":"function",
                    "name": func.get("name"),
                    "description": func.get("description",""),
                    "parameters": func.get("parameters")
                })
            else:
                resp_tools.append(t)
        payload["tools"] = resp_tools
    if tool_choice is not None:
        if isinstance(tool_choice, str):
            payload["tool_choice"] = tool_choice
        elif isinstance(tool_choice, dict):
            if tool_choice.get("type") == "function":
                func = tool_choice.get("function", {})
                payload["tool_choice"] = {"type":"function","name": func.get("name")}
            else:
                payload["tool_choice"] = tool_choice
    if temperature is not None:
        payload["temperature"] = temperature
    if max_tokens is not None:
        payload["max_output_tokens"] = max_tokens

    return payload, effort

def responses_to_chat(resp_json, chat_model, chat_id_prefix="chatcmpl-compat"):
    model = resp_json.get("model", chat_model)
    output = resp_json.get("output", [])
    usage = resp_json.get("usage", {})
    content_parts = []
    tool_calls = []
    for item in output:
        if item.get("type") == "message":
            for c in item.get("content", []):
                if c.get("type") == "output_text":
                    content_parts.append(c.get("text",""))
        elif item.get("type") == "function_call":
            call_id = item.get("call_id") or item.get("id") or f"call_{uuid.uuid4().hex[:8]}"
            name = item.get("name")
            arguments = item.get("arguments", "{}")
            if isinstance(arguments, dict):
                arguments = json.dumps(arguments)
            tool_calls.append({
                "id": call_id,
                "type": "function",
                "function": {"name": name, "arguments": arguments}
            })
    content = "".join(content_parts) if content_parts else None
    if content == "":
        content = None
    finish_reason = "tool_calls" if tool_calls else "stop"
    # handle incomplete truncation
    incomplete = resp_json.get("incomplete_details")
    if incomplete and incomplete.get("reason") == "max_output_tokens":
        finish_reason = "length"
    choice = {
        "index": 0,
        "message": {"role":"assistant","content": content},
        "finish_reason": finish_reason
    }
    if tool_calls:
        choice["message"]["tool_calls"] = tool_calls
    # also include logprobs etc if needed
    chat_resp = {
        "id": resp_json.get("id", f"{chat_id_prefix}-{uuid.uuid4().hex[:8]}"),
        "object": "chat.completion",
        "created": int(time.time()),
        "model": model,
        "choices": [choice],
        "usage": {
            "prompt_tokens": usage.get("input_tokens", 0),
            "completion_tokens": usage.get("output_tokens", 0),
            "total_tokens": usage.get("total_tokens", 0)
        }
    }
    # preserve reasoning tokens if available
    if "output_tokens_details" in usage:
        chat_resp["usage"]["reasoning_tokens"] = usage["output_tokens_details"].get("reasoning_tokens", 0)
    return chat_resp

class CompatHandler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/v1/models"):
            self.proxy_models()
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"not found")

    def do_POST(self):
        if self.path.startswith("/v1/chat/completions"):
            self.handle_chat()
        elif self.path.startswith("/v1/responses"):
            # direct passthrough for direct inference test
            self.proxy_responses()
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"not found")

    def proxy_models(self):
        auth = get_auth_header(self.headers)
        session = str(uuid.uuid4())
        headers = {"Authorization": auth, "x-opencode-session": session, "User-Agent": _USER_AGENT}
        target = f"{UPSTREAM}{self.path}"
        req = urllib.request.Request(target, headers=headers, method="GET")
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                body = resp.read()
                self.send_response(resp.status)
                for k,v in resp.getheaders():
                    if k.lower() in ("transfer-encoding",): continue
                    self.send_header(k,v)
                self.end_headers()
                self.wfile.write(body)
        except urllib.error.HTTPError as e:
            self.send_response(e.code)
            for k,v in e.headers.items():
                if k.lower() in ("transfer-encoding",): continue
                self.send_header(k,v)
            self.end_headers()
            self.wfile.write(e.read())
        except Exception as e:
            self.send_response(502)
            self.end_headers()
            self.wfile.write(f"gateway error: {e}".encode())

    def proxy_responses(self):
        # direct passthrough
        length = int(self.headers.get("Content-Length",0))
        body = self.rfile.read(length) if length>0 else b""
        auth = get_auth_header(self.headers)
        session = self.headers.get("x-opencode-session") or str(uuid.uuid4())
        headers = {"Authorization": auth, "x-opencode-session": session, "User-Agent": _USER_AGENT, "Content-Type":"application/json"}
        target = f"{UPSTREAM}{self.path}"
        req = urllib.request.Request(target, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                resp_body = resp.read()
                self.send_response(resp.status)
                for k,v in resp.getheaders():
                    if k.lower() in ("transfer-encoding",): continue
                    self.send_header(k,v)
                self.end_headers()
                self.wfile.write(resp_body)
        except urllib.error.HTTPError as e:
            self.send_response(e.code)
            for k,v in e.headers.items():
                if k.lower() in ("transfer-encoding",): continue
                self.send_header(k,v)
            self.end_headers()
            self.wfile.write(e.read())
        except Exception as e:
            self.send_response(502)
            self.end_headers()
            self.wfile.write(f"gateway error: {e}".encode())

    def handle_chat(self):
        length = int(self.headers.get("Content-Length",0))
        body = self.rfile.read(length) if length>0 else b"{}"
        try:
            chat_body = json.loads(body.decode('utf-8'))
        except:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"invalid json")
            return
        # log redacted
        redacted = {
            "ts": int(time.time()),
            "model": chat_body.get("model"),
            "messages_sample": str(chat_body.get("messages",[]))[:500],
            "tools_count": len(chat_body.get("tools",[])),
            "tool_choice": chat_body.get("tool_choice"),
            "stream": chat_body.get("stream", False),
            "temperature": chat_body.get("temperature"),
            "max_tokens": chat_body.get("max_tokens"),
            "effort": chat_body.get("reasoning_effort") or chat_body.get("effort") or (chat_body.get("reasoning",{}).get("effort") if isinstance(chat_body.get("reasoning"),dict) else None)
        }
        redacted_log("chat_in", redacted)

        responses_payload, effort = chat_to_responses(chat_body)
        # log responses payload redacted
        redacted_log("responses_out", {"model": responses_payload.get("model"), "effort": effort, "input_items": len(responses_payload.get("input",[])), "tools": len(responses_payload.get("tools",[]))})

        # forward to upstream
        auth = get_auth_header(self.headers)
        if not auth:
            self.send_response(401)
            self.end_headers()
            self.wfile.write(b'{"error":{"type":"auth_error","message":"missing Authorization"}}')
            return
        session = str(uuid.uuid4())
        headers = {"Authorization": auth, "x-opencode-session": session, "User-Agent": _USER_AGENT, "Content-Type":"application/json"}
        target = f"{UPSTREAM}/v1/responses"
        data = json.dumps(responses_payload).encode('utf-8')
        try:
            req = urllib.request.Request(target, data=data, headers=headers, method="POST")
            with urllib.request.urlopen(req, timeout=120) as resp:
                resp_body = resp.read()
                resp_json = json.loads(resp_body.decode('utf-8'))
                # log backend
                redacted_log("responses_in", {"model": resp_json.get("model"), "status": resp_json.get("status"), "usage": resp_json.get("usage"), "reasoning": resp_json.get("reasoning")})
                # translate back
                chat_resp = responses_to_chat(resp_json, chat_body.get("model"))
                # log chat out
                redacted_log("chat_out", {"model": chat_resp.get("model"), "finish_reason": chat_resp["choices"][0]["finish_reason"], "tool_calls": len(chat_resp["choices"][0]["message"].get("tool_calls",[])), "usage": chat_resp.get("usage")})
                is_stream = chat_body.get("stream", False)
                if is_stream:
                    # emit SSE streaming
                    self.send_response(200)
                    self.send_header("Content-Type","text/event-stream")
                    self.send_header("Cache-Control","no-cache")
                    self.send_header("Connection","keep-alive")
                    self.end_headers()
                    # chunk 1: role delta
                    chunk_role = {"id": chat_resp["id"], "object":"chat.completion.chunk", "created": chat_resp["created"], "model": chat_resp["model"], "choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":None}]}
                    self.wfile.write(f"data: {json.dumps(chunk_role)}\n\n".encode())
                    # content chunks
                    content = chat_resp["choices"][0]["message"].get("content")
                    tool_calls = chat_resp["choices"][0]["message"].get("tool_calls")
                    if content:
                        # split content into 2 chunks for realism
                        mid = len(content)//2
                        for part in [content[:mid], content[mid:]]:
                            if part:
                                chunk = {"id": chat_resp["id"], "object":"chat.completion.chunk", "created": chat_resp["created"], "model": chat_resp["model"], "choices":[{"index":0,"delta":{"content": part},"finish_reason":None}]}
                                self.wfile.write(f"data: {json.dumps(chunk)}\n\n".encode())
                    if tool_calls:
                        for tc in tool_calls:
                            chunk = {"id": chat_resp["id"], "object":"chat.completion.chunk", "created": chat_resp["created"], "model": chat_resp["model"], "choices":[{"index":0,"delta":{"tool_calls":[{"index":0,"id": tc["id"],"type":"function","function":{"name": tc["function"]["name"],"arguments": tc["function"]["arguments"]}}]},"finish_reason":None}]}
                            self.wfile.write(f"data: {json.dumps(chunk)}\n\n".encode())
                    # final
                    chunk_final = {"id": chat_resp["id"], "object":"chat.completion.chunk", "created": chat_resp["created"], "model": chat_resp["model"], "choices":[{"index":0,"delta":{},"finish_reason": chat_resp["choices"][0]["finish_reason"]}], "usage": chat_resp.get("usage")}
                    self.wfile.write(f"data: {json.dumps(chunk_final)}\n\n".encode())
                    self.wfile.write(b"data: [DONE]\n\n")
                else:
                    body_out = json.dumps(chat_resp).encode('utf-8')
                    self.send_response(200)
                    self.send_header("Content-Type","application/json")
                    self.send_header("Content-Length", str(len(body_out)))
                    self.end_headers()
                    self.wfile.write(body_out)
        except urllib.error.HTTPError as e:
            err_body = e.read()
            # passthrough error as chat error shape but preserve status
            # try to map responses error to chat error
            try:
                err_json = json.loads(err_body.decode('utf-8'))
                # wrap as chat error
                chat_err = {"error": err_json.get("error", {"message": err_body.decode('utf-8')[:500], "type":"provider_error"})}
                out = json.dumps(chat_err).encode('utf-8')
            except:
                out = err_body
            self.send_response(e.code)
            for k,v in e.headers.items():
                if k.lower() in ("transfer-encoding","content-length"): continue
                self.send_header(k,v)
            self.send_header("Content-Type","application/json")
            self.end_headers()
            self.wfile.write(out)
        except Exception as e:
            self.send_response(502)
            self.end_headers()
            self.wfile.write(f"gateway error: {e}".encode())

    def log_message(self, format, *args):
        pass

if __name__ == "__main__":
    print(f"COMPAT_GATEWAY_READY port={PORT} upstream={UPSTREAM}", flush=True)
    server = http.server.HTTPServer(("0.0.0.0", PORT), CompatHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()
